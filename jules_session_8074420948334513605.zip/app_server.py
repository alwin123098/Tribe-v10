import os
import uuid
import yaml
import numpy as np
import pandas as pd
from pathlib import Path
from typing import List, Optional
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from tribev2 import TribeModel
from tribev2.plotting.cortical import PlotBrainNilearn

app = FastAPI(title="TRIBE v2 Brain Encoding Server")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directories
STATIC_DIR = Path("./static")
PRED_DIR = STATIC_DIR / "predictions"
PLOT_DIR = STATIC_DIR / "plots"
DEMO_DIR = STATIC_DIR / "demos"

for folder in [PRED_DIR, PLOT_DIR, DEMO_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

# Global variables
model = None

def get_model():
    global model
    if model is None:
        print("Loading TRIBE v2 model from pretrained weights...")
        import torch
        device_str = "cuda" if torch.cuda.is_available() else "cpu"
        model = TribeModel.from_pretrained(
            "facebook/tribev2",
            cache_folder="./cache",
            device=device_str,
            config_update={"data.text_feature.model_name": "unsloth/Llama-3.2-3B"}
        )
    return model

# Create automatic demo files if they do not exist
def setup_demos():
    demo_text_path = DEMO_DIR / "demo_text.txt"
    if not demo_text_path.exists():
        demo_text_path.write_text("Exploring the human brain with deep learning and functional magnetic resonance imaging (fMRI).")

    demo_audio_path = DEMO_DIR / "demo_audio.mp3"
    if not demo_audio_path.exists():
        try:
            from gtts import gTTS
            tts = gTTS("Exploring the human brain with deep learning and functional magnetic resonance imaging (fMRI).", lang="en")
            tts.save(str(demo_audio_path))
            print("Generated demo audio via gTTS successfully.")
        except Exception as e:
            print(f"Error generating demo audio: {e}")

    # Generate a demo video
    demo_video_path = DEMO_DIR / "demo_video.mp4"
    if not demo_video_path.exists():
        try:
            from moviepy import ImageClip
            from PIL import Image
            img_path = DEMO_DIR / "temp.png"
            img = Image.new('RGB', (320, 240), color='blue')
            img.save(img_path)
            clip = ImageClip(str(img_path), duration=3.0)
            clip.write_videofile(str(demo_video_path), codec="libx264", fps=5, logger=None)
            img_path.unlink(missing_ok=True)
            print("Generated demo video successfully.")
        except Exception as e:
            print(f"Error generating demo video: {e}")

setup_demos()

@app.get("/api/demo-samples")
def get_demo_samples():
    return {
        "text": "Exploring the human brain with deep learning and functional magnetic resonance imaging (fMRI).",
        "audio": {
            "name": "Demo Speech (Synthesized)",
            "path": "/static/demos/demo_audio.mp3"
        },
        "video": {
            "name": "Demo Video (Blue Static)",
            "path": "/static/demos/demo_video.mp4"
        }
    }

@app.post("/api/predict")
async def run_prediction(
    mode: str = Form(...), # "text", "audio", "video", "demo_text", "demo_audio", "demo_video"
    text: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None)
):
    try:
        m = get_model()
        temp_id = str(uuid.uuid4())
        
        # Determine the input file/content
        input_path = None
        if mode == "text":
            if not text:
                raise HTTPException(status_code=400, detail="Text parameter is missing for text mode.")
            input_path = PRED_DIR / f"{temp_id}.txt"
            input_path.write_text(text)
        elif mode == "demo_text":
            input_path = DEMO_DIR / "demo_text.txt"
        elif mode == "demo_audio":
            input_path = DEMO_DIR / "demo_audio.mp3"
        elif mode == "demo_video":
            input_path = DEMO_DIR / "demo_video.mp4"
        elif mode in ("audio", "video"):
            if not file:
                raise HTTPException(status_code=400, detail="Uploaded file is missing.")
            ext = Path(file.filename).suffix
            input_path = PRED_DIR / f"{temp_id}{ext}"
            with open(input_path, "wb") as f:
                f.write(await file.read())
        else:
            raise HTTPException(status_code=400, detail=f"Invalid mode specified: {mode}")

        # Run inference
        print(f"Running TRIBE v2 inference in mode {mode} on path: {input_path}")
        if "text" in mode:
            df = m.get_events_dataframe(text_path=str(input_path))
        elif "audio" in mode:
            df = m.get_events_dataframe(audio_path=str(input_path))
        elif "video" in mode:
            df = m.get_events_dataframe(video_path=str(input_path))
        else:
            raise HTTPException(status_code=400, detail="Unsupported mode mapping.")

        preds, segments = m.predict(events=df, verbose=False)
        print(f"Inference completed. Predictions shape: {preds.shape}")

        # Save predictions and segment metadata
        pred_id = str(uuid.uuid4())
        preds_save_path = PRED_DIR / f"{pred_id}_preds.npy"
        np.save(preds_save_path, preds)

        serialized_segments = []
        for seg in segments:
            words = []
            sentences = []
            for e in seg.ns_events:
                class_name = e.__class__.__name__
                if class_name == "Word":
                    words.append({
                        "text": e.text,
                        "start": e.start,
                        "duration": e.duration,
                        "sentence": getattr(e, "sentence", "")
                    })
                elif class_name in ("Sentence", "Text"):
                    sentences.append(e.text)

            serialized_segments.append({
                "start": seg.start,
                "duration": seg.duration,
                "stop": seg.stop,
                "words": words,
                "sentences": list(set(sentences))
            })

        # Save segments to JSON
        import json
        segments_save_path = PRED_DIR / f"{pred_id}_segments.json"
        with open(segments_save_path, "w") as f:
            json.dump(serialized_segments, f)

        # Cleanup custom input text files to save disk
        if mode == "text" and input_path and input_path.exists():
            input_path.unlink(missing_ok=True)

        return {
            "prediction_id": pred_id,
            "num_timesteps": preds.shape[0],
            "segments": serialized_segments
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/plot")
def plot_brain(
    prediction_id: str,
    timestep: int = 0,
    cmap: str = "fire",
    views: str = "left,right",
    symmetric_cbar: bool = False
):
    try:
        preds_path = PRED_DIR / f"{prediction_id}_preds.npy"
        if not preds_path.exists():
            raise HTTPException(status_code=404, detail="Prediction ID not found.")

        preds = np.load(preds_path)
        if timestep < 0 or timestep >= preds.shape[0]:
            timestep = max(0, min(timestep, preds.shape[0] - 1))

        # Check if the plot was already generated and cached
        view_key = views.replace(",", "_")
        cache_plot_path = PLOT_DIR / f"{prediction_id}_{timestep}_{cmap}_{view_key}_{int(symmetric_cbar)}.png"
        if cache_plot_path.exists():
            return FileResponse(cache_plot_path)

        # Draw the plot
        views_list = views.split(",")
        plotter = PlotBrainNilearn(mesh="fsaverage5")
        
        fig, axarr = plotter.get_fig_axes(views=views_list)
        plotter.plot_surf(
            preds[timestep],
            axes=axarr,
            views=views_list,
            cmap=cmap,
            symmetric_cbar=symmetric_cbar
        )
        
        plt.savefig(cache_plot_path, bbox_inches='tight', dpi=150, transparent=True)
        plt.close(fig)

        return FileResponse(cache_plot_path)

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/prediction/{prediction_id}")
def delete_prediction(prediction_id: str):
    preds_path = PRED_DIR / f"{prediction_id}_preds.npy"
    segments_path = PRED_DIR / f"{prediction_id}_segments.json"
    
    deleted = False
    if preds_path.exists():
        preds_path.unlink()
        deleted = True
    if segments_path.exists():
        segments_path.unlink()
        deleted = True
        
    # Delete any related plots
    for p in PLOT_DIR.glob(f"{prediction_id}_*.png"):
        p.unlink()
        
    return {"success": deleted}

# Mount static folders for preloaded demos
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# Serve built production assets of the React frontend
FRONTEND_DIST = Path("./safeguard-saas/dist")
if FRONTEND_DIST.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIST), html=True), name="frontend")
else:
    @app.get("/")
    def index():
        return JSONResponse({
            "message": "TRIBE v2 Brain Encoding Server active. Please build the frontend React application in safeguard-saas to serve it here."
        })
