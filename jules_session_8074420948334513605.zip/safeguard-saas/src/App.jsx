import React, { useState, useEffect, useRef } from "react";
import {
  Brain,
  Video,
  Music,
  FileText,
  Play,
  Pause,
  RotateCcw,
  Download,
  Database,
  Terminal,
  Settings,
  ChevronRight,
  Loader2,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  BookOpen,
  Volume2,
  Flame,
  Globe,
  Sliders,
  Trash2
} from "lucide-react";

// --- INITIAL STATE & CONFIG ---
const THEME = {
  bg: "bg-slate-950",
  text: "text-slate-100",
  border: "border-slate-800",
  card: "bg-slate-900/60 backdrop-blur-md",
  accent: "from-indigo-500 to-purple-600",
  accentGlow: "shadow-indigo-500/20"
};

const COLORMAPS = [
  { id: "fire", name: "Fire (Warm)", icon: Flame },
  { id: "cold_hot", name: "Cold-Hot (Two-sided)", icon: Sliders },
  { id: "hot", name: "Hot (Red-Yellow)", icon: Flame },
  { id: "jet", name: "Jet (Rainbow)", icon: Globe },
  { id: "viridis", name: "Viridis (High contrast)", icon: Sparkles },
  { id: "magma", name: "Magma (Dark-Purple-Orange)", icon: Database }
];

export default function App() {
  const [activeTab, setActiveTab] = useState("workspace"); // workspace, demos, explanation, api
  const [inputMode, setInputMode] = useState("text"); // text, audio, video
  
  // Custom Inputs
  const [customText, setCustomText] = useState(
    "Exploring the human brain with deep learning and functional magnetic resonance imaging (fMRI)."
  );
  const [audioFile, setAudioFile] = useState(null);
  const [videoFile, setVideoFile] = useState(null);

  // Settings
  const [selectedCmap, setSelectedCmap] = useState("fire");
  const [selectedViews, setSelectedViews] = useState("left,right");
  const [symmetricCbar, setSymmetricCbar] = useState(false);

  // Processing & Results State
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null); // { prediction_id, num_timesteps, segments }
  
  // Playback State
  const [currentTimeStep, setCurrentTimeStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playSpeed, setPlaySpeed] = useState(1000); // ms per timestep
  
  // Demo Samples metadata from backend
  const [serverStatus, setServerStatus] = useState("checking");

  const playbackTimer = useRef(null);

  // Check backend server status & load demo samples
  useEffect(() => {
    fetch("/api/demo-samples")
      .then((res) => {
        if (!res.ok) throw new Error("Server not responding");
        return res.json();
      })
      .then(() => {
        setServerStatus("connected");
      })
      .catch((err) => {
        console.error(err);
        setServerStatus("disconnected");
      });
  }, []);

  // Handle auto-advance playback
  useEffect(() => {
    if (isPlaying && result) {
      playbackTimer.current = setInterval(() => {
        setCurrentTimeStep((prev) => {
          if (prev >= result.num_timesteps - 1) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, playSpeed);
    } else {
      if (playbackTimer.current) clearInterval(playbackTimer.current);
    }
    return () => {
      if (playbackTimer.current) clearInterval(playbackTimer.current);
    };
  }, [isPlaying, result, playSpeed]);

  const handleRunInference = async (modeOverride = null) => {
    setLoading(true);
    setError(null);
    setResult(null);
    setCurrentTimeStep(0);
    setIsPlaying(false);

    // Simulated pipeline step transitions for deep user engagement
    const steps = [
      "Synthesizing audio & extracting events timeline...",
      "Extracting auditory features via Wav2Vec-Bert...",
      "Extracting text token embeddings via un-gated Llama 3.2 3B...",
      "Passing multimodal tokens to TRIBE v2 Unified Transformer...",
      "Projecting final activations to fsaverage5 cortical surface..."
    ];

    let currentStep = 0;
    setLoadingStep(0);
    const stepInterval = setInterval(() => {
      if (currentStep < steps.length - 1) {
        currentStep++;
        setLoadingStep(currentStep);
      }
    }, 2800);

    try {
      const formData = new FormData();
      const runMode = modeOverride || inputMode;
      formData.append("mode", runMode);

      if (runMode === "text") {
        formData.append("text", customText);
      } else if (runMode === "audio") {
        if (!audioFile) throw new Error("Please upload an audio file first!");
        formData.append("file", audioFile);
      } else if (runMode === "video") {
        if (!videoFile) throw new Error("Please upload a video file first!");
        formData.append("file", videoFile);
      }

      const response = await fetch("/api/predict", {
        method: "POST",
        body: formData
      });

      clearInterval(stepInterval);

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || "Inference failed");
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      clearInterval(stepInterval);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePrediction = async () => {
    if (!result) return;
    try {
      await fetch(`/api/prediction/${result.prediction_id}`, { method: "DELETE" });
      setResult(null);
      setCurrentTimeStep(0);
    } catch (e) {
      console.error(e);
    }
  };

  const getBrainImageUrl = () => {
    if (!result) return "";
    return `/api/plot?prediction_id=${result.prediction_id}&timestep=${currentTimeStep}&cmap=${selectedCmap}&views=${selectedViews}&symmetric_cbar=${symmetricCbar}`;
  };

  const loadingPipelineSteps = [
    { title: "Input Preprocessing", desc: "Generating speech with gTTS or loading custom clips" },
    { title: "Wav2Vec Auditory Alignment", desc: "Transcribing audio segments & extracting word timings" },
    { title: "Llama-3.2 Activation Extractor", desc: "Encoding linguistic semantics into deep token matrices" },
    { title: "Foundation Transformer", desc: "Synthesizing vision, audition, and language cues" },
    { title: "Hemodynamic Prediction", desc: "Mapping temporal brain activity onto 20,484 surface vertices" }
  ];

  return (
    <div className={`min-h-screen ${THEME.bg} ${THEME.text} font-sans flex flex-col selection:bg-indigo-500 selection:text-white`}>
      {/* --- TOP BRANDING HEADER --- */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/30">
              <Brain className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-400">
                  TribeFlow
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full">
                  TRIBE v2
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">In-Silico Multimodal Neuroscience Platform</p>
            </div>
          </div>

          {/* Tab Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {[
              { id: "workspace", name: "Inference Workspace", icon: Brain },
              { id: "demos", name: "Preset Showcases", icon: Sparkles },
              { id: "explanation", name: "How It Works", icon: BookOpen },
              { id: "api", name: "Developer API", icon: Terminal }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ${
                    isActive
                      ? "bg-slate-900 text-white border border-slate-800"
                      : "text-slate-400 hover:text-slate-100 hover:bg-slate-900/40"
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-indigo-400" : ""}`} />
                  {tab.name}
                </button>
              );
            })}
          </nav>

          {/* Connection Status Badge */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800/80 rounded-full py-1.5 px-3">
              <span className={`w-2.5 h-2.5 rounded-full ${
                serverStatus === "connected" ? "bg-emerald-500 animate-pulse" : serverStatus === "checking" ? "bg-amber-500 animate-spin" : "bg-rose-500"
              }`} />
              <span className="text-xs font-semibold text-slate-400 capitalize">
                Server: {serverStatus}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Tab Fallback Header */}
      <div className="md:hidden border-b border-slate-900 bg-slate-950 flex justify-around p-2 text-xs font-semibold">
        <button onClick={() => setActiveTab("workspace")} className={activeTab === "workspace" ? "text-indigo-400" : "text-slate-400"}>Workspace</button>
        <button onClick={() => setActiveTab("demos")} className={activeTab === "demos" ? "text-indigo-400" : "text-slate-400"}>Presets</button>
        <button onClick={() => setActiveTab("explanation")} className={activeTab === "explanation" ? "text-indigo-400" : "text-slate-400"}>Science</button>
        <button onClick={() => setActiveTab("api")} className={activeTab === "api" ? "text-indigo-400" : "text-slate-400"}>Developer API</button>
      </div>

      {/* --- MAIN PAGE CONTENT --- */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 gap-6">
        {/* --- WORKSPACE TAB --- */}
        {activeTab === "workspace" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Inputs Section (5 cols) */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-5 shadow-2xl flex flex-col gap-5`}>
                <div>
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    <Sliders className="w-5 h-5 text-indigo-400" />
                    Stimulus Settings
                  </h2>
                  <p className="text-xs text-slate-500">Provide language, speech, or video to stimulate the virtual brain model.</p>
                </div>

                {/* Input Mode Selector Tab buttons */}
                <div className="grid grid-cols-3 bg-slate-950 p-1 rounded-xl border border-slate-900">
                  {[
                    { id: "text", name: "Text Input", icon: FileText },
                    { id: "audio", name: "Upload Audio", icon: Music },
                    { id: "video", name: "Upload Video", icon: Video }
                  ].map((mode) => {
                    const Icon = mode.icon;
                    return (
                      <button
                        key={mode.id}
                        onClick={() => {
                          setInputMode(mode.id);
                          setError(null);
                        }}
                        className={`flex flex-col items-center gap-1.5 py-2.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
                          inputMode === mode.id
                            ? "bg-slate-900 text-indigo-400 border border-slate-800 shadow"
                            : "text-slate-400 hover:text-slate-200"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {mode.name}
                      </button>
                    );
                  })}
                </div>

                {/* Modality Specific Input Forms */}
                <div className="flex-1 min-h-[160px] flex flex-col justify-center">
                  {inputMode === "text" && (
                    <div className="flex flex-col gap-3">
                      <label className="text-xs font-semibold text-slate-400">Custom Text Prompt</label>
                      <textarea
                        value={customText}
                        onChange={(e) => setCustomText(e.target.value)}
                        className="w-full h-32 px-4 py-3 rounded-xl bg-slate-950/60 border border-slate-900 text-sm focus:border-indigo-500 focus:outline-none transition-all resize-none text-slate-300 font-medium"
                        placeholder="Enter custom sentence or paragraph..."
                      />
                      <p className="text-[10px] text-slate-500">
                        * Note: Text prompt is automatically synthesized to speech via gTTS and aligned using a lightweight Whisper model before predictive scoring.
                      </p>
                    </div>
                  )}

                  {inputMode === "audio" && (
                    <div className="flex flex-col gap-3">
                      <label className="text-xs font-semibold text-slate-400">Audio Stimulus Upload (.mp3, .wav)</label>
                      <div className="border border-dashed border-slate-800 hover:border-indigo-500/60 rounded-xl p-6 bg-slate-950/40 text-center cursor-pointer transition-all">
                        <input
                          type="file"
                          accept=".mp3,.wav"
                          onChange={(e) => setAudioFile(e.target.files[0])}
                          className="hidden"
                          id="audio-upload"
                        />
                        <label htmlFor="audio-upload" className="cursor-pointer flex flex-col items-center gap-2">
                          <Music className="w-8 h-8 text-indigo-500/70" />
                          <span className="text-sm font-semibold text-slate-300">
                            {audioFile ? audioFile.name : "Choose audio file or drag it here"}
                          </span>
                          <span className="text-xs text-slate-500">Supports standard WAV / MP3</span>
                        </label>
                      </div>
                    </div>
                  )}

                  {inputMode === "video" && (
                    <div className="flex flex-col gap-3">
                      <label className="text-xs font-semibold text-slate-400">Video Stimulus Upload (.mp4)</label>
                      <div className="border border-dashed border-slate-800 hover:border-indigo-500/60 rounded-xl p-6 bg-slate-950/40 text-center cursor-pointer transition-all">
                        <input
                          type="file"
                          accept=".mp4"
                          onChange={(e) => setVideoFile(e.target.files[0])}
                          className="hidden"
                          id="video-upload"
                        />
                        <label htmlFor="video-upload" className="cursor-pointer flex flex-col items-center gap-2">
                          <Video className="w-8 h-8 text-indigo-500/70" />
                          <span className="text-sm font-semibold text-slate-300">
                            {videoFile ? videoFile.name : "Choose video file or drag it here"}
                          </span>
                          <span className="text-xs text-slate-500">Supports h.264 standard MP4</span>
                        </label>
                      </div>
                    </div>
                  )}
                </div>

                {/* Visualization Style Panel */}
                <div className="border-t border-slate-900 pt-4 flex flex-col gap-4">
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                    <Settings className="w-4 h-4 text-indigo-400" />
                    Visualization Styles
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-500">Cortical Colormap</label>
                      <select
                        value={selectedCmap}
                        onChange={(e) => setSelectedCmap(e.target.value)}
                        className="w-full mt-1.5 px-3 py-2 text-xs font-semibold bg-slate-950 border border-slate-900 rounded-lg text-slate-300 focus:outline-none"
                      >
                        {COLORMAPS.map((cmap) => (
                          <option key={cmap.id} value={cmap.id}>{cmap.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-500">Mesh Views</label>
                      <select
                        value={selectedViews}
                        onChange={(e) => setSelectedViews(e.target.value)}
                        className="w-full mt-1.5 px-3 py-2 text-xs font-semibold bg-slate-950 border border-slate-900 rounded-lg text-slate-300 focus:outline-none"
                      >
                        <option value="left,right">Both Hemispheres</option>
                        <option value="left">Left Lateral</option>
                        <option value="right">Right Lateral</option>
                        <option value="medial_left,medial_right">Both Medial Views</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-1">
                    <input
                      type="checkbox"
                      id="symmetric-cbar"
                      checked={symmetricCbar}
                      onChange={(e) => setSymmetricCbar(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-900 text-indigo-500 focus:ring-indigo-500"
                    />
                    <label htmlFor="symmetric-cbar" className="text-xs font-semibold text-slate-400 cursor-pointer">
                      Symmetric Colorbar (Zero-centered)
                    </label>
                  </div>
                </div>

                {/* Primary CTA button */}
                <button
                  onClick={() => handleRunInference()}
                  disabled={loading}
                  className="w-full py-3.5 px-6 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-500 to-purple-600 hover:opacity-90 active:scale-[0.98] transition-all text-white flex items-center justify-center gap-2 shadow-xl shadow-indigo-500/20 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Processing Stimulus...
                    </>
                  ) : (
                    <>
                      <Brain className="w-5 h-5" />
                      Simulate Brain Response
                    </>
                  )}
                </button>
              </div>

              {/* Preloaded Demo Shortcuts quick bar */}
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-5 shadow flex flex-col gap-3.5`}>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                  <span className="text-xs font-bold uppercase tracking-wider text-purple-300">Preset Quick Launches</span>
                </div>
                <p className="text-[11px] text-slate-500">No uploads needed. Test the model immediately using preloaded high-fidelity inputs.</p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleRunInference("demo_text")}
                    disabled={loading}
                    className="py-2.5 px-2 bg-slate-950 hover:bg-slate-900 border border-slate-900 hover:border-slate-800 rounded-xl text-[11px] font-bold text-slate-300 flex flex-col items-center gap-1.5 transition-all"
                  >
                    <FileText className="w-4 h-4 text-blue-400" />
                    Neuro Text
                  </button>
                  <button
                    onClick={() => handleRunInference("demo_audio")}
                    disabled={loading}
                    className="py-2.5 px-2 bg-slate-950 hover:bg-slate-900 border border-slate-900 hover:border-slate-800 rounded-xl text-[11px] font-bold text-slate-300 flex flex-col items-center gap-1.5 transition-all"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                    Speech Audio
                  </button>
                  <button
                    onClick={() => handleRunInference("demo_video")}
                    disabled={loading}
                    className="py-2.5 px-2 bg-slate-950 hover:bg-slate-900 border border-slate-900 hover:border-slate-800 rounded-xl text-[11px] font-bold text-slate-300 flex flex-col items-center gap-1.5 transition-all"
                  >
                    <Video className="w-4 h-4 text-rose-400" />
                    Moving Video
                  </button>
                </div>
              </div>
            </div>

            {/* Right Display Area (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              {/* Error Alert */}
              {error && (
                <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-2xl flex flex-col gap-2">
                  <h4 className="font-bold text-sm">Simulation Pipeline Error</h4>
                  <p className="text-xs leading-relaxed">{error}</p>
                </div>
              )}

              {/* Loader with Pipeline Step Tracker */}
              {loading && (
                <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-8 flex flex-col items-center justify-center min-h-[450px]`}>
                  <Loader2 className="w-16 h-16 text-indigo-500 animate-spin mb-6" />
                  <h3 className="text-lg font-extrabold mb-1 bg-clip-text text-transparent bg-gradient-to-r from-indigo-300 to-purple-300">
                    Executing Brain Encoding Simulation
                  </h3>
                  <p className="text-xs text-slate-400 mb-8 max-w-sm text-center">
                    Please hold. Mapping input structures through Whisper alignment and un-gated Llama-3.2 matrices.
                  </p>

                  {/* Step Indicators */}
                  <div className="w-full max-w-md flex flex-col gap-3">
                    {loadingPipelineSteps.map((step, idx) => {
                      const isPast = idx < loadingStep;
                      const isCurrent = idx === loadingStep;
                      return (
                        <div
                          key={idx}
                          className={`flex items-start gap-3 p-3 rounded-xl border transition-all duration-300 ${
                            isCurrent
                              ? "bg-slate-950 border-indigo-500/30 shadow-lg shadow-indigo-500/5"
                              : isPast
                              ? "bg-slate-900/40 border-slate-900 opacity-60"
                              : "border-transparent opacity-30"
                          }`}
                        >
                          <div className="mt-0.5">
                            {isPast ? (
                              <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                            ) : isCurrent ? (
                              <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500 font-bold">
                                {idx + 1}
                              </div>
                            )}
                          </div>
                          <div>
                            <h4 className={`text-xs font-bold ${isCurrent ? "text-indigo-300" : isPast ? "text-slate-300" : "text-slate-500"}`}>
                              {step.title}
                            </h4>
                            <p className="text-[10px] text-slate-500 font-medium">{step.desc}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Placeholder when no results and not loading */}
              {!loading && !result && (
                <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-8 flex flex-col items-center justify-center min-h-[450px] text-center`}>
                  <div className="p-4 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-4 animate-bounce">
                    <Brain className="w-12 h-12" />
                  </div>
                  <h3 className="text-lg font-bold mb-1">Simulated Brain Activity Output</h3>
                  <p className="text-xs text-slate-500 max-w-sm leading-relaxed mb-6">
                    Enter text or upload media, then launch the simulation to see fMRI-like predicted patterns on the fsaverage5 cortical surface in real-time.
                  </p>
                  <button
                    onClick={() => handleRunInference("demo_text")}
                    className="py-2.5 px-5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold rounded-xl text-slate-300 transition-all flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    Load Demo Stimulus to Start
                  </button>
                </div>
              )}

              {/* Complete Interactive Results Panel */}
              {!loading && result && (
                <div className="flex flex-col gap-6">
                  {/* Result Header Stats */}
                  <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-4 flex items-center justify-between shadow`}>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                        <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold">Simulation Successful</h4>
                        <p className="text-[10px] text-slate-500">
                          ID: {result.prediction_id.slice(0, 12)}... | Generated {result.num_timesteps} brain timesteps
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={`/api/plot?prediction_id=${result.prediction_id}&timestep=${currentTimeStep}&cmap=${selectedCmap}&views=${selectedViews}&symmetric_cbar=${symmetricCbar}`}
                        download={`brain_t${currentTimeStep}.png`}
                        title="Download plotted PNG"
                        className="p-2 rounded-lg bg-slate-950 border border-slate-900 hover:bg-slate-900 text-slate-400 hover:text-slate-200 transition-all"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                      <button
                        onClick={handleDeletePrediction}
                        title="Clear and Delete prediction files"
                        className="p-2 rounded-lg bg-slate-950 border border-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Dual columns: timeline vs brain visualization */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                    {/* Brain visualizer column (7 cols) */}
                    <div className="md:col-span-7 flex flex-col gap-4">
                      <div className="bg-slate-950 border border-slate-900 rounded-2xl p-4 flex flex-col items-center justify-center relative min-h-[300px] shadow-2xl overflow-hidden group">
                        <div className="absolute top-3 left-3 bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1 text-[10px] font-bold text-slate-400 z-10">
                          Timestep: {currentTimeStep}s
                        </div>

                        {/* RENDERED PLOT IMAGE */}
                        <img
                          src={getBrainImageUrl()}
                          alt={`Brain response at timestep ${currentTimeStep}`}
                          className="max-h-[280px] object-contain transition-all duration-300 drop-shadow-[0_10px_30px_rgba(99,102,241,0.15)] group-hover:scale-[1.02]"
                        />

                        {/* Floating colorbar legend */}
                        <div className="w-full max-w-[200px] mt-2 flex flex-col gap-1 items-center bg-slate-900/60 p-2 rounded-lg border border-slate-800/60">
                          <div className={`w-full h-2 rounded bg-gradient-to-r ${
                            selectedCmap === "viridis" ? "from-purple-800 via-teal-500 to-yellow-400" : "from-red-600 via-amber-400 to-yellow-200"
                          }`} />
                          <div className="w-full flex justify-between text-[8px] font-extrabold text-slate-500 tracking-wider">
                            <span>{symmetricCbar ? "-MAX" : "REST"}</span>
                            <span>ACTIVE (+MAX)</span>
                          </div>
                        </div>
                      </div>

                      {/* Timestep scrubber timeline */}
                      <div className={`${THEME.card} border ${THEME.border} p-4 rounded-2xl flex flex-col gap-3 shadow`}>
                        <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                          <span>Scrub Hemodynamic Timeline</span>
                          <span className="text-indigo-400">t = {currentTimeStep} seconds</span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={result.num_timesteps - 1}
                          value={currentTimeStep}
                          onChange={(e) => setCurrentTimeStep(parseInt(e.target.value))}
                          className="w-full accent-indigo-500 h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setIsPlaying(!isPlaying)}
                              className="p-2 rounded-lg bg-indigo-500 text-white hover:opacity-90 transition"
                            >
                              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                            </button>
                            <button
                              onClick={() => {
                                setCurrentTimeStep(0);
                                setIsPlaying(false);
                              }}
                              className="p-2 rounded-lg bg-slate-950 border border-slate-900 hover:bg-slate-900 text-slate-400 hover:text-slate-200 transition"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          </div>
                          
                          {/* Speed selector */}
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-500 font-bold uppercase">Frame Interval</span>
                            <select
                              value={playSpeed}
                              onChange={(e) => setPlaySpeed(parseInt(e.target.value))}
                              className="px-2 py-1 text-[10px] font-bold bg-slate-950 border border-slate-900 rounded-md text-slate-400"
                            >
                              <option value={1500}>1.5s (Slow)</option>
                              <option value={1000}>1.0s (Normal)</option>
                              <option value={500}>0.5s (Fast)</option>
                              <option value={250}>0.25s (Super Fast)</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Timeline & words alignment column (5 cols) */}
                    <div className="md:col-span-5 flex flex-col gap-4">
                      <div className="text-xs font-bold text-slate-400 uppercase tracking-widest pl-1">Aligned Linguistic Stimuli</div>
                      
                      <div className="flex-1 max-h-[380px] overflow-y-auto border border-slate-900 bg-slate-950/40 rounded-2xl p-4 flex flex-col gap-3.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                        {result.segments && result.segments.length > 0 ? (
                          result.segments.map((seg, idx) => {
                            const isSelected = currentTimeStep === idx;
                            return (
                              <div
                                key={idx}
                                onClick={() => {
                                  setCurrentTimeStep(idx);
                                  setIsPlaying(false);
                                }}
                                className={`p-3 rounded-xl border text-left cursor-pointer transition-all duration-200 ${
                                  isSelected
                                    ? "bg-indigo-500/10 border-indigo-500/40 shadow-md shadow-indigo-500/5"
                                    : "border-slate-900 hover:border-slate-800 bg-slate-900/10"
                                }`}
                              >
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className={`text-[9px] font-extrabold uppercase tracking-widest px-1.5 py-0.5 rounded-md ${
                                    isSelected ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-900 text-slate-500"
                                  }`}>
                                    TR Segment {idx} (t={idx}s)
                                  </span>
                                  <span className="text-[9px] font-bold text-slate-500">
                                    {seg.start.toFixed(1)}s - {seg.stop.toFixed(1)}s
                                  </span>
                                </div>
                                
                                {/* Words list */}
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {seg.words && seg.words.length > 0 ? (
                                    seg.words.map((w, wIdx) => (
                                      <span
                                        key={wIdx}
                                        title={`Aligned Word. Start: ${w.start.toFixed(2)}s`}
                                        className="px-1.5 py-0.5 text-xs font-semibold bg-slate-950/80 border border-slate-900 rounded-md text-slate-300 hover:border-indigo-500/30 transition-colors"
                                      >
                                        {w.text}
                                      </span>
                                    ))
                                  ) : seg.sentences && seg.sentences.length > 0 ? (
                                    <span className="text-xs font-medium text-slate-300 leading-relaxed">
                                      {seg.sentences[0]}
                                    </span>
                                  ) : (
                                    <span className="text-[10px] text-slate-600 font-bold italic">No text events in segment</span>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="h-full flex items-center justify-center text-xs text-slate-500 font-bold italic">
                            No segments detected.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- PRESETS TAB --- */}
        {activeTab === "demos" && (
          <div className="flex flex-col gap-6">
            <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-6`}>
              <h2 className="text-xl font-extrabold mb-1 bg-clip-text text-transparent bg-gradient-to-r from-indigo-300 to-purple-300">
                Preset Showcases
              </h2>
              <p className="text-xs text-slate-500">
                These are pre-rendered datasets demonstrating how the human brain encodes various naturalistic modalities. Select a preset below to instantly load it into your Workspace.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  id: "demo_text",
                  title: "Neuroscience Abstract Prompt",
                  type: "Language Stimulus",
                  desc: "A pure linguistics trial showcasing semantic representation. Triggers localized activity across classical language areas like Wernicke's & Broca's regions.",
                  icon: FileText,
                  color: "border-blue-500/20 hover:border-blue-500/40"
                },
                {
                  id: "demo_audio",
                  title: "Synthesized Explanation Speech",
                  type: "Auditory Stimulus",
                  desc: "Features continuous auditory input via speech wave. Stimulates primary and secondary auditory cortex along the superior temporal gyrus.",
                  icon: Volume2,
                  color: "border-emerald-500/20 hover:border-emerald-500/40"
                },
                {
                  id: "demo_video",
                  title: "Moving Visual Matrix",
                  type: "Visual & Auditory Stimulus",
                  desc: "Combines temporal audio frequency with continuous moving video frames. Activates massive regions along the visual pathway (V1 to MT+).",
                  icon: Video,
                  color: "border-rose-500/20 hover:border-rose-500/40"
                }
              ].map((preset) => {
                const Icon = preset.icon;
                return (
                  <div
                    key={preset.id}
                    onClick={() => {
                      setInputMode(preset.id.split("_")[1]);
                      setActiveTab("workspace");
                      handleRunInference(preset.id);
                    }}
                    className={`bg-slate-900/40 border border-slate-900 ${preset.color} rounded-2xl p-6 cursor-pointer transition-all hover:scale-[1.02] flex flex-col gap-4 shadow-xl`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                        <Icon className="w-5 h-5 text-indigo-400" />
                      </div>
                      <div>
                        <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-400">
                          {preset.type}
                        </span>
                        <h4 className="font-bold text-sm text-slate-200 mt-0.5">{preset.title}</h4>
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed flex-1">{preset.desc}</p>
                    <button className="py-2 px-4 rounded-xl bg-slate-950 border border-slate-900 text-xs font-bold text-slate-300 flex items-center justify-center gap-2 group-hover:bg-indigo-600 transition">
                      Load Preset
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* --- EXPLANATION TAB --- */}
        {activeTab === "explanation" && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-8 flex flex-col gap-6">
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-6 flex flex-col gap-4 shadow-xl`}>
                <h2 className="text-xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                  A Foundation Model of Vision, Audition, and Language for In-Silico Neuroscience
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  TRIBE v2 is a unified deep multimodal brain encoding architecture. It takes naturalistic stimuli—video, audio, or text—and predicts complex blood-oxygen-level-dependent (BOLD) fMRI brain responses across the cortical surface of the average human subject.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-2">
                  <div className="p-4 bg-slate-950 border border-slate-900 rounded-xl">
                    <h4 className="text-xs font-bold text-slate-400 mb-1">Unified Transformer</h4>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      Maps cross-modal representations seamlessly onto the cortical sheet, using advanced neural tokenization.
                    </p>
                  </div>
                  <div className="p-4 bg-slate-950 border border-slate-900 rounded-xl">
                    <h4 className="text-xs font-bold text-slate-400 mb-1">fsaverage5 Mesh</h4>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      Generates high-resolution spatial predictions across ~20,484 surface vertices in less than a second.
                    </p>
                  </div>
                  <div className="p-4 bg-slate-950 border border-slate-900 rounded-xl">
                    <h4 className="text-xs font-bold text-slate-400 mb-1">Hemodynamic Offset</h4>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      Offset by 5 seconds in the past to fully compensate for the physiological hemodynamic response delay.
                    </p>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-indigo-300 mt-2">Pipeline Architecture</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Input signals are transformed using dedicated, pre-aligned foundation models:
                </p>
                <ul className="list-disc list-inside text-xs text-slate-500 leading-relaxed space-y-1.5 pl-2">
                  <li><strong className="text-slate-300">Text Mode:</strong> Synthesized to speech via gTTS and aligned back using WhisperX to construct accurate timelines. Words are tokenized via un-gated <strong className="text-indigo-400">Llama-3.2 3B</strong> model to extract deep semantic features.</li>
                  <li><strong className="text-slate-300">Audio Mode:</strong> Processed via <strong className="text-indigo-400">Wav2Vec-Bert 2.0</strong> to capture continuous acoustic representations.</li>
                  <li><strong className="text-slate-300">Video Mode:</strong> Split into frame sequences and parsed via <strong className="text-indigo-400">V-JEPA (facebook/vjepa2)</strong> to capture dense visual flow.</li>
                </ul>
              </div>

              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-6 flex flex-col gap-3 shadow-xl`}>
                <h3 className="text-sm font-bold text-slate-200">Scientific Citation</h3>
                <p className="text-xs text-slate-500">
                  If you use this model or server in your scientific workflow, please reference the original paper:
                </p>
                <pre className="p-4 bg-slate-950 border border-slate-900 rounded-xl text-[10px] text-slate-400 font-mono overflow-x-auto">
{`@article{dascoli2026foundation,
  title={A foundation model of vision, audition, and language for in-silico neuroscience},
  author={d'Ascoli, Stéphane and Rapin, Jérémy and Benchetrit, Yohann and Brooks, Teon and Begany, Katelyn and Rougel, Joséphine and Banville, Hubert and King, Jean-Rémi},
  journal={arXiv preprint arXiv:2605.04326},
  year={2026}
}`}
                </pre>
              </div>
            </div>

            <div className="md:col-span-4 flex flex-col gap-6">
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-5 shadow flex flex-col gap-4`}>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <ExternalLink className="w-4 h-4 text-indigo-400" />
                  Official Links
                </h4>
                <div className="flex flex-col gap-2.5">
                  <a
                    href="https://arxiv.org/abs/2605.04326"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-900 hover:border-slate-800 rounded-xl text-xs font-semibold text-slate-300 flex items-center justify-between transition-colors"
                  >
                    <span>Read Paper on arXiv</span>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </a>
                  <a
                    href="https://huggingface.co/facebook/tribev2"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-900 hover:border-slate-800 rounded-xl text-xs font-semibold text-slate-300 flex items-center justify-between transition-colors"
                  >
                    <span>HuggingFace Repository</span>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* --- API REFERENCE TAB --- */}
        {activeTab === "api" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 flex flex-col gap-6">
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-6 flex flex-col gap-4 shadow-xl`}>
                <h2 className="text-xl font-extrabold mb-1 bg-clip-text text-transparent bg-gradient-to-r from-indigo-300 to-purple-300">
                  Developer In-Silico API
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  This server exposes a fully documented REST API allowing developers to trigger TRIBE v2 simulations programmatically from Python scripts, notebooks, or external agents.
                </p>

                {/* API table */}
                <div className="border border-slate-900 rounded-xl overflow-hidden bg-slate-950">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-900/60 border-b border-slate-800 text-slate-400 font-bold">
                        <th className="p-3">Method</th>
                        <th className="p-3">Endpoint</th>
                        <th className="p-3">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900 text-slate-300 font-medium">
                      <tr>
                        <td className="p-3 text-indigo-400 font-bold">POST</td>
                        <td className="p-3 font-mono">/api/predict</td>
                        <td className="p-3 text-slate-400">Run multimodal brain activity inference.</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-emerald-400 font-bold">GET</td>
                        <td className="p-3 font-mono">/api/plot</td>
                        <td className="p-3 text-slate-400">Generate 2D/3D Nilearn brain surface visuals.</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-indigo-400 font-bold">GET</td>
                        <td className="p-3 font-mono">/api/demo-samples</td>
                        <td className="p-3 text-slate-400">Fetch metadata of preloaded presets.</td>
                      </tr>
                      <tr>
                        <td className="p-3 text-rose-400 font-bold">DELETE</td>
                        <td className="p-3 font-mono">/api/prediction/{"{id}"}</td>
                        <td className="p-3 text-slate-400">Clean up cache prediction outputs.</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Code Snippet Example */}
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-6 flex flex-col gap-3 shadow-xl`}>
                <h3 className="text-sm font-bold text-slate-200">Python Integration Example</h3>
                <p className="text-xs text-slate-500">
                  You can query this server with standard python tools. Perfect for integration with downstream analysis!
                </p>
                <pre className="p-4 bg-slate-950 border border-slate-900 rounded-xl text-[11px] text-slate-400 font-mono overflow-x-auto leading-relaxed">
{`import requests

# 1. Trigger Simulation
res = requests.post(
    "http://localhost:8000/api/predict",
    data={"mode": "text", "text": "This stimulates the temporal lobe."}
)
data = res.json()
pred_id = data["prediction_id"]

# 2. Retrieve beautiful brain surface visualization
img_res = requests.get(
    f"http://localhost:8000/api/plot?prediction_id={pred_id}&timestep=0&cmap=fire"
)
with open("simulated_brain.png", "wb") as f:
    f.write(img_res.content)
print("Brain visual downloaded!")`}
                </pre>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-6">
              <div className={`${THEME.card} border ${THEME.border} rounded-2xl p-5 shadow flex flex-col gap-4`}>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  Active Server Config
                </h4>
                <div className="flex flex-col gap-3 text-xs">
                  <div className="flex justify-between border-b border-slate-900 pb-2">
                    <span className="text-slate-500">Backend Port</span>
                    <span className="font-mono text-indigo-400">8000</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-900 pb-2">
                    <span className="text-slate-500">Device Target</span>
                    <span className="font-mono text-indigo-400">CPU (Optimized)</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-900 pb-2">
                    <span className="text-slate-500">Whisper Engine</span>
                    <span className="font-mono text-indigo-400">tiny / int8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Text Embedder</span>
                    <span className="font-mono text-indigo-400">Llama-3.2-3B</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* --- FOOTER --- */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 text-center text-xs text-slate-600 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© 2026 TribeFlow Platforms. Released under CC BY-NC 4.0 license.</p>
          <div className="flex items-center gap-6 font-semibold">
            <span className="text-slate-500">fsaverage5 Mesh</span>
            <span className="text-slate-500">~20,484 Vertices</span>
            <span className="text-slate-500">Hemodynamic Lag compensated</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
